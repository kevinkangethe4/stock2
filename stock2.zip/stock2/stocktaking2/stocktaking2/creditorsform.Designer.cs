﻿namespace stocktaking2
{
    partial class creditorsform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(creditorsform));
            System.Windows.Forms.Label cREDITORIdLabel;
            System.Windows.Forms.Label iTEMLabel;
            System.Windows.Forms.Label qUANITYLabel;
            System.Windows.Forms.Label pRICE_UNITLabel;
            System.Windows.Forms.Label tOTALPRICELabel;
            System.Windows.Forms.Label nAMELabel;
            System.Windows.Forms.Label dATELabel;
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stock = new stocktaking2.stock();
            this.cREBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cRETableAdapter = new stocktaking2.stockTableAdapters.CRETableAdapter();
            this.tableAdapterManager = new stocktaking2.stockTableAdapters.TableAdapterManager();
            this.cREBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.cREBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cREDITORIdTextBox = new System.Windows.Forms.TextBox();
            this.iTEMTextBox = new System.Windows.Forms.TextBox();
            this.qUANITYTextBox = new System.Windows.Forms.TextBox();
            this.pRICE_UNITTextBox = new System.Windows.Forms.TextBox();
            this.tOTALPRICETextBox = new System.Windows.Forms.TextBox();
            this.nAMETextBox = new System.Windows.Forms.TextBox();
            this.dATEDateTimePicker = new System.Windows.Forms.DateTimePicker();
            cREDITORIdLabel = new System.Windows.Forms.Label();
            iTEMLabel = new System.Windows.Forms.Label();
            qUANITYLabel = new System.Windows.Forms.Label();
            pRICE_UNITLabel = new System.Windows.Forms.Label();
            tOTALPRICELabel = new System.Windows.Forms.Label();
            nAMELabel = new System.Windows.Forms.Label();
            dATELabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cREBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cREBindingNavigator)).BeginInit();
            this.cREBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(cREDITORIdLabel);
            this.groupBox1.Controls.Add(this.cREDITORIdTextBox);
            this.groupBox1.Controls.Add(iTEMLabel);
            this.groupBox1.Controls.Add(this.iTEMTextBox);
            this.groupBox1.Controls.Add(qUANITYLabel);
            this.groupBox1.Controls.Add(this.qUANITYTextBox);
            this.groupBox1.Controls.Add(pRICE_UNITLabel);
            this.groupBox1.Controls.Add(this.pRICE_UNITTextBox);
            this.groupBox1.Controls.Add(tOTALPRICELabel);
            this.groupBox1.Controls.Add(this.tOTALPRICETextBox);
            this.groupBox1.Controls.Add(nAMELabel);
            this.groupBox1.Controls.Add(this.nAMETextBox);
            this.groupBox1.Controls.Add(dATELabel);
            this.groupBox1.Controls.Add(this.dATEDateTimePicker);
            this.groupBox1.Location = new System.Drawing.Point(18, 59);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(709, 448);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // stock
            // 
            this.stock.DataSetName = "stock";
            this.stock.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cREBindingSource
            // 
            this.cREBindingSource.DataMember = "CRE";
            this.cREBindingSource.DataSource = this.stock;
            // 
            // cRETableAdapter
            // 
            this.cRETableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CRETableAdapter = this.cRETableAdapter;
            this.tableAdapterManager.DEBTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.stockinTableAdapter = null;
            this.tableAdapterManager.STOCKOUTTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = stocktaking2.stockTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // cREBindingNavigator
            // 
            this.cREBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.cREBindingNavigator.BindingSource = this.cREBindingSource;
            this.cREBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.cREBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.cREBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.cREBindingNavigatorSaveItem});
            this.cREBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.cREBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.cREBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.cREBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.cREBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.cREBindingNavigator.Name = "cREBindingNavigator";
            this.cREBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.cREBindingNavigator.Size = new System.Drawing.Size(1028, 25);
            this.cREBindingNavigator.TabIndex = 1;
            this.cREBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // cREBindingNavigatorSaveItem
            // 
            this.cREBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cREBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("cREBindingNavigatorSaveItem.Image")));
            this.cREBindingNavigatorSaveItem.Name = "cREBindingNavigatorSaveItem";
            this.cREBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.cREBindingNavigatorSaveItem.Text = "Save Data";
            this.cREBindingNavigatorSaveItem.Click += new System.EventHandler(this.cREBindingNavigatorSaveItem_Click);
            // 
            // cREDITORIdLabel
            // 
            cREDITORIdLabel.AutoSize = true;
            cREDITORIdLabel.Location = new System.Drawing.Point(17, 88);
            cREDITORIdLabel.Name = "cREDITORIdLabel";
            cREDITORIdLabel.Size = new System.Drawing.Size(103, 16);
            cREDITORIdLabel.TabIndex = 0;
            cREDITORIdLabel.Text = "CREDITORId:";
            // 
            // cREDITORIdTextBox
            // 
            this.cREDITORIdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cREBindingSource, "CREDITORId", true));
            this.cREDITORIdTextBox.Location = new System.Drawing.Point(153, 88);
            this.cREDITORIdTextBox.Name = "cREDITORIdTextBox";
            this.cREDITORIdTextBox.Size = new System.Drawing.Size(522, 22);
            this.cREDITORIdTextBox.TabIndex = 1;
            // 
            // iTEMLabel
            // 
            iTEMLabel.AutoSize = true;
            iTEMLabel.Location = new System.Drawing.Point(19, 200);
            iTEMLabel.Name = "iTEMLabel";
            iTEMLabel.Size = new System.Drawing.Size(48, 16);
            iTEMLabel.TabIndex = 2;
            iTEMLabel.Text = "ITEM:";
            // 
            // iTEMTextBox
            // 
            this.iTEMTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cREBindingSource, "ITEM", true));
            this.iTEMTextBox.Location = new System.Drawing.Point(153, 197);
            this.iTEMTextBox.Name = "iTEMTextBox";
            this.iTEMTextBox.Size = new System.Drawing.Size(522, 22);
            this.iTEMTextBox.TabIndex = 3;
            // 
            // qUANITYLabel
            // 
            qUANITYLabel.AutoSize = true;
            qUANITYLabel.Location = new System.Drawing.Point(17, 231);
            qUANITYLabel.Name = "qUANITYLabel";
            qUANITYLabel.Size = new System.Drawing.Size(79, 16);
            qUANITYLabel.TabIndex = 4;
            qUANITYLabel.Text = "QUANITY:";
            // 
            // qUANITYTextBox
            // 
            this.qUANITYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cREBindingSource, "QUANITY", true));
            this.qUANITYTextBox.Location = new System.Drawing.Point(153, 225);
            this.qUANITYTextBox.Name = "qUANITYTextBox";
            this.qUANITYTextBox.Size = new System.Drawing.Size(522, 22);
            this.qUANITYTextBox.TabIndex = 5;
            // 
            // pRICE_UNITLabel
            // 
            pRICE_UNITLabel.AutoSize = true;
            pRICE_UNITLabel.Location = new System.Drawing.Point(19, 256);
            pRICE_UNITLabel.Name = "pRICE_UNITLabel";
            pRICE_UNITLabel.Size = new System.Drawing.Size(98, 16);
            pRICE_UNITLabel.TabIndex = 6;
            pRICE_UNITLabel.Text = "PRICE/UNIT:";
            // 
            // pRICE_UNITTextBox
            // 
            this.pRICE_UNITTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cREBindingSource, "PRICE/UNIT", true));
            this.pRICE_UNITTextBox.Location = new System.Drawing.Point(153, 253);
            this.pRICE_UNITTextBox.Name = "pRICE_UNITTextBox";
            this.pRICE_UNITTextBox.Size = new System.Drawing.Size(522, 22);
            this.pRICE_UNITTextBox.TabIndex = 7;
            // 
            // tOTALPRICELabel
            // 
            tOTALPRICELabel.AutoSize = true;
            tOTALPRICELabel.Location = new System.Drawing.Point(19, 287);
            tOTALPRICELabel.Name = "tOTALPRICELabel";
            tOTALPRICELabel.Size = new System.Drawing.Size(106, 16);
            tOTALPRICELabel.TabIndex = 8;
            tOTALPRICELabel.Text = "TOTALPRICE:";
            // 
            // tOTALPRICETextBox
            // 
            this.tOTALPRICETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cREBindingSource, "TOTALPRICE", true));
            this.tOTALPRICETextBox.Location = new System.Drawing.Point(153, 281);
            this.tOTALPRICETextBox.Name = "tOTALPRICETextBox";
            this.tOTALPRICETextBox.Size = new System.Drawing.Size(522, 22);
            this.tOTALPRICETextBox.TabIndex = 9;
            // 
            // nAMELabel
            // 
            nAMELabel.AutoSize = true;
            nAMELabel.Location = new System.Drawing.Point(17, 136);
            nAMELabel.Name = "nAMELabel";
            nAMELabel.Size = new System.Drawing.Size(55, 16);
            nAMELabel.TabIndex = 10;
            nAMELabel.Text = "NAME:";
            // 
            // nAMETextBox
            // 
            this.nAMETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cREBindingSource, "NAME", true));
            this.nAMETextBox.Location = new System.Drawing.Point(153, 130);
            this.nAMETextBox.Name = "nAMETextBox";
            this.nAMETextBox.Size = new System.Drawing.Size(522, 22);
            this.nAMETextBox.TabIndex = 11;
            // 
            // dATELabel
            // 
            dATELabel.AutoSize = true;
            dATELabel.Location = new System.Drawing.Point(19, 163);
            dATELabel.Name = "dATELabel";
            dATELabel.Size = new System.Drawing.Size(53, 16);
            dATELabel.TabIndex = 12;
            dATELabel.Text = "DATE:";
            // 
            // dATEDateTimePicker
            // 
            this.dATEDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.cREBindingSource, "DATE", true));
            this.dATEDateTimePicker.Location = new System.Drawing.Point(153, 158);
            this.dATEDateTimePicker.Name = "dATEDateTimePicker";
            this.dATEDateTimePicker.Size = new System.Drawing.Size(522, 22);
            this.dATEDateTimePicker.TabIndex = 13;
            // 
            // creditorsform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Fuchsia;
            this.ClientSize = new System.Drawing.Size(1028, 564);
            this.Controls.Add(this.cREBindingNavigator);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "creditorsform";
            this.Text = "creditorsform";
            this.Load += new System.EventHandler(this.creditorsform_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cREBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cREBindingNavigator)).EndInit();
            this.cREBindingNavigator.ResumeLayout(false);
            this.cREBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private stock stock;
        private System.Windows.Forms.BindingSource cREBindingSource;
        private stockTableAdapters.CRETableAdapter cRETableAdapter;
        private stockTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator cREBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton cREBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox cREDITORIdTextBox;
        private System.Windows.Forms.TextBox iTEMTextBox;
        private System.Windows.Forms.TextBox qUANITYTextBox;
        private System.Windows.Forms.TextBox pRICE_UNITTextBox;
        private System.Windows.Forms.TextBox tOTALPRICETextBox;
        private System.Windows.Forms.TextBox nAMETextBox;
        private System.Windows.Forms.DateTimePicker dATEDateTimePicker;
    }
}