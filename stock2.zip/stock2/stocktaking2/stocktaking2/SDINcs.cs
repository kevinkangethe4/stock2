﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace stocktaking2
{
    public partial class SDINcs : Form
    {
        public SDINcs()
        {
            InitializeComponent();
        }

        private void stockinBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockinBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void SDINcs_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.stockin' table. You can move, or remove it, as needed.
            this.stockinTableAdapter.Fill(this.stock.stockin);

        }

        private void search2ToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            PrintDocument doc = new PrintDocument();
            doc.PrintPage += this.printDocument1_PrintPage;
            PrintDialog dlg = new PrintDialog();
            dlg.Document = doc;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                doc.Print();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap BN = new Bitmap(this.groupBox1.Width, this.groupBox1.Height);
            groupBox1.DrawToBitmap(BN, new Rectangle(0, 0, this.groupBox1.Width, this.groupBox1.Height));
            e.Graphics.DrawImage(BN, 0, 0);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < stockinDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(stockinDataGridView.Rows[i].Cells[4].Value);
            }

            textBox1.Text = sum.ToString();
        }

        private void sEARCHToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.stockinTableAdapter.SEARCH(this.stock.stockin, new System.Nullable<System.DateTime>(((System.DateTime)(System.Convert.ChangeType(lIKEToolStripTextBox.Text, typeof(System.DateTime))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }  
    }
}
