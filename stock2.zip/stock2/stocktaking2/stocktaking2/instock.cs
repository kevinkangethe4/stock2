﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class instock : Form
    {
        public instock()
        {
            InitializeComponent();
        }

        private void stockinBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockinBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void instock_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.stockin' table. You can move, or remove it, as needed.
            this.stockinTableAdapter.Fill(this.stock.stockin);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Add new records");
            this.stockinBindingSource.AddNew();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockinBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);
            MessageBox.Show("Record Updated");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a, b;
            bool at=int.TryParse(qUANITITYTextBox.Text,out a);
            bool bt =int.TryParse(pRICE_UNITTextBox.Text,out b);
            if (bt && bt)
                tOTALPRICETextBox.Text = (a * b).ToString();
            else tOTALPRICETextBox.Text = "invalid";

          

        }
    }
}
