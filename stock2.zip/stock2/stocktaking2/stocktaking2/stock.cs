﻿namespace stocktaking2 {
    
    
    public partial class stock {
        partial class stockinDataTable
        {
        }
    }
}
