﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sTOCKINFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            instock FG = new instock();
            FG.ShowDialog();
        }

        private void sTOCKOUTFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outstock FG = new outstock();
            FG.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void iNREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void oUTREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void sEARCHITEMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            insearch bn = new insearch();
            bn.ShowDialog();
        }

        private void sEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SDINcs NM = new SDINcs();
            NM.ShowDialog();
        }

        private void dEBTORToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void dEBTORFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmdebtor DF = new frmdebtor();
            DF.ShowDialog();

        }

        private void dEBTORREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SEARCHDEB fg = new SEARCHDEB();
            fg.ShowDialog();
        }

        private void sEARCHDEBTORBYITEMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SIDEB fb = new SIDEB();
            fb.ShowDialog();
        }

        private void sEARCHITEMSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OUTIT XC = new OUTIT();
            XC.ShowDialog();

        }

        private void searchByDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SODATE DF = new SODATE();
            DF.ShowDialog();

        }

        private void pLREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PandLIState cv = new PandLIState();
            cv.ShowDialog();
        }

        private void cREDITORFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            creditorsform cv = new creditorsform();
            cv.ShowDialog();
        }

        private void cREDITORToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cREDITORSREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sercn fg = new sercn();
            fg.ShowDialog();

        }

        private void sEARCHBYITEMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CIS GH = new CIS();
            GH.ShowDialog();

        }

        private void sEARCHBYITEMToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            insearch bn = new insearch();
            bn.ShowDialog();
        }

        private void sTOCKINFORMToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            instock FG = new instock();
            FG.ShowDialog();
        }

        private void sEARCHBYDATEToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SDINcs NM = new SDINcs();
            NM.ShowDialog();
        }

        private void fORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outstock FG = new outstock();
            FG.ShowDialog();
        }

        private void bYITEMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OUTIT XC = new OUTIT();
            XC.ShowDialog();
        }

        private void bYDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SODATE DF = new SODATE();
            DF.ShowDialog();

        }

        private void sTATEMENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PandLIState cv = new PandLIState();
            cv.ShowDialog();
        }

        private void dEBTORSFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmdebtor DF = new frmdebtor();
            DF.ShowDialog();

        }

        private void iTEMToolStripMenuItem_Click(object sender, EventArgs e)
        {
             SEARCHDEB fg = new SEARCHDEB();
            fg.ShowDialog();
        
        }

        private void dATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SIDEB fb = new SIDEB();
            fb.ShowDialog();
        }

        private void cREDITORSFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            creditorsform cv = new creditorsform();
            cv.ShowDialog();
        }

        private void nAMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sercn fg = new sercn();
            fg.ShowDialog();

        }

        private void iTEMSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CIS GH = new CIS();
            GH.ShowDialog();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void sEARCHACCOUNTINGPERIODToolStripMenuItem_Click(object sender, EventArgs e)
        {
            INACCSEARCH DF = new INACCSEARCH();
            DF.ShowDialog();

        }

        private void sEARCHBYACCOUNTPERIODToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saccno vb = new saccno();
            vb.ShowDialog();
        }

        private void pLREPORTBYACCOUNTPERIODToolStripMenuItem_Click(object sender, EventArgs e)
        {
            apl cv = new apl();
            cv.ShowDialog();
        }
    }
}