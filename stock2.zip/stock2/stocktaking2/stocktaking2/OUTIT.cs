﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace stocktaking2
{
    public partial class OUTIT : Form
    {
        public OUTIT()
        {
            InitializeComponent();
        }

        private void sTOCKOUTBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sTOCKOUTBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void OUTIT_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.STOCKOUT' table. You can move, or remove it, as needed.
            this.sTOCKOUTTableAdapter.Fill(this.stock.STOCKOUT);

        }

        private void sTOCKOUTDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void sEARCH_ITEM_NAMEToolStripButton_Click(object sender, EventArgs e)
        {
         

        }

        private void button1_Click(object sender, EventArgs e)
        {

            int sum = 0;
            for (int i = 0; i < sTOCKOUTDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(sTOCKOUTDataGridView.Rows[i].Cells[6].Value);
            }

            textBox1.Text = sum.ToString();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Bitmap BN = new Bitmap(this.groupBox1.Width, this.groupBox1.Height);
            groupBox1.DrawToBitmap(BN, new Rectangle(0, 0, this.groupBox1.Width, this.groupBox1.Height));
            e.Graphics.DrawImage(BN, 0, 0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PrintDocument doc = new PrintDocument();
            doc.PrintPage += this.printDocument1_PrintPage;
            PrintDialog dlg = new PrintDialog();
            dlg.Document = doc;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                doc.Print();
            }
        }

        private void search1ToolStripButton_Click(object sender, EventArgs e)
        {
            
        }

        private void search3ToolStripButton_Click(object sender, EventArgs e)
        {
           
        }

        private void sEARCH11ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.sTOCKOUTTableAdapter.SEARCH11(this.stock.STOCKOUT, lIKEToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
