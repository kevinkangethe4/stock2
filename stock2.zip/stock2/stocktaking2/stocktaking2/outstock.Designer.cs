﻿namespace stocktaking2
{
    partial class outstock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iTEMNUMBERLabel;
            System.Windows.Forms.Label iTEMNAMELabel;
            System.Windows.Forms.Label qUANITITYLabel;
            System.Windows.Forms.Label pRICEPERUNITLabel;
            System.Windows.Forms.Label dATELabel;
            System.Windows.Forms.Label sERVEBYLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(outstock));
            System.Windows.Forms.Label aCCPERIODLabel;
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.iTEMNUMBERTextBox = new System.Windows.Forms.TextBox();
            this.iTEMNAMETextBox = new System.Windows.Forms.TextBox();
            this.qUANITITYTextBox = new System.Windows.Forms.TextBox();
            this.pRICEPERUNITTextBox = new System.Windows.Forms.TextBox();
            this.tOTALPRICETextBox = new System.Windows.Forms.TextBox();
            this.dATEDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.sERVEBYTextBox = new System.Windows.Forms.TextBox();
            this.sTOCKOUTBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.sTOCKOUTBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.sTOCKOUTDataGridView = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.sTOCKOUTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stock = new stocktaking2.stock();
            this.sTOCKOUTTableAdapter = new stocktaking2.stockTableAdapters.STOCKOUTTableAdapter();
            this.tableAdapterManager = new stocktaking2.stockTableAdapters.TableAdapterManager();
            this.aCCPERIODTextBox = new System.Windows.Forms.TextBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            iTEMNUMBERLabel = new System.Windows.Forms.Label();
            iTEMNAMELabel = new System.Windows.Forms.Label();
            qUANITITYLabel = new System.Windows.Forms.Label();
            pRICEPERUNITLabel = new System.Windows.Forms.Label();
            dATELabel = new System.Windows.Forms.Label();
            sERVEBYLabel = new System.Windows.Forms.Label();
            aCCPERIODLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sTOCKOUTBindingNavigator)).BeginInit();
            this.sTOCKOUTBindingNavigator.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sTOCKOUTDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTOCKOUTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).BeginInit();
            this.SuspendLayout();
            // 
            // iTEMNUMBERLabel
            // 
            iTEMNUMBERLabel.AutoSize = true;
            iTEMNUMBERLabel.Location = new System.Drawing.Point(30, 26);
            iTEMNUMBERLabel.Name = "iTEMNUMBERLabel";
            iTEMNUMBERLabel.Size = new System.Drawing.Size(94, 13);
            iTEMNUMBERLabel.TabIndex = 0;
            iTEMNUMBERLabel.Text = "ITEMNUMBER:";
            // 
            // iTEMNAMELabel
            // 
            iTEMNAMELabel.AutoSize = true;
            iTEMNAMELabel.Location = new System.Drawing.Point(30, 52);
            iTEMNAMELabel.Name = "iTEMNAMELabel";
            iTEMNAMELabel.Size = new System.Drawing.Size(80, 13);
            iTEMNAMELabel.TabIndex = 2;
            iTEMNAMELabel.Text = "ITEM NAME:";
            // 
            // qUANITITYLabel
            // 
            qUANITITYLabel.AutoSize = true;
            qUANITITYLabel.Location = new System.Drawing.Point(30, 78);
            qUANITITYLabel.Name = "qUANITITYLabel";
            qUANITITYLabel.Size = new System.Drawing.Size(78, 13);
            qUANITITYLabel.TabIndex = 4;
            qUANITITYLabel.Text = "QUANITITY:";
            // 
            // pRICEPERUNITLabel
            // 
            pRICEPERUNITLabel.AutoSize = true;
            pRICEPERUNITLabel.Location = new System.Drawing.Point(30, 104);
            pRICEPERUNITLabel.Name = "pRICEPERUNITLabel";
            pRICEPERUNITLabel.Size = new System.Drawing.Size(111, 13);
            pRICEPERUNITLabel.TabIndex = 6;
            pRICEPERUNITLabel.Text = "PRICE PER UNIT:";
            // 
            // dATELabel
            // 
            dATELabel.AutoSize = true;
            dATELabel.Location = new System.Drawing.Point(30, 157);
            dATELabel.Name = "dATELabel";
            dATELabel.Size = new System.Drawing.Size(44, 13);
            dATELabel.TabIndex = 10;
            dATELabel.Text = "DATE:";
            // 
            // sERVEBYLabel
            // 
            sERVEBYLabel.AutoSize = true;
            sERVEBYLabel.Location = new System.Drawing.Point(30, 182);
            sERVEBYLabel.Name = "sERVEBYLabel";
            sERVEBYLabel.Size = new System.Drawing.Size(68, 13);
            sERVEBYLabel.TabIndex = 12;
            sERVEBYLabel.Text = "SERVEBY:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(aCCPERIODLabel);
            this.groupBox1.Controls.Add(this.aCCPERIODTextBox);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(iTEMNUMBERLabel);
            this.groupBox1.Controls.Add(this.iTEMNUMBERTextBox);
            this.groupBox1.Controls.Add(iTEMNAMELabel);
            this.groupBox1.Controls.Add(this.iTEMNAMETextBox);
            this.groupBox1.Controls.Add(qUANITITYLabel);
            this.groupBox1.Controls.Add(this.qUANITITYTextBox);
            this.groupBox1.Controls.Add(pRICEPERUNITLabel);
            this.groupBox1.Controls.Add(this.pRICEPERUNITTextBox);
            this.groupBox1.Controls.Add(this.tOTALPRICETextBox);
            this.groupBox1.Controls.Add(dATELabel);
            this.groupBox1.Controls.Add(this.dATEDateTimePicker);
            this.groupBox1.Controls.Add(sERVEBYLabel);
            this.groupBox1.Controls.Add(this.sERVEBYTextBox);
            this.groupBox1.Location = new System.Drawing.Point(14, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(735, 254);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Magenta;
            this.button1.Location = new System.Drawing.Point(24, 125);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 30);
            this.button1.TabIndex = 14;
            this.button1.Text = "Total Price";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // iTEMNUMBERTextBox
            // 
            this.iTEMNUMBERTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sTOCKOUTBindingSource, "ITEMNUMBER", true));
            this.iTEMNUMBERTextBox.Location = new System.Drawing.Point(142, 23);
            this.iTEMNUMBERTextBox.Name = "iTEMNUMBERTextBox";
            this.iTEMNUMBERTextBox.Size = new System.Drawing.Size(233, 20);
            this.iTEMNUMBERTextBox.TabIndex = 1;
            // 
            // iTEMNAMETextBox
            // 
            this.iTEMNAMETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sTOCKOUTBindingSource, "ITEMNAME", true));
            this.iTEMNAMETextBox.Location = new System.Drawing.Point(142, 49);
            this.iTEMNAMETextBox.Name = "iTEMNAMETextBox";
            this.iTEMNAMETextBox.Size = new System.Drawing.Size(233, 20);
            this.iTEMNAMETextBox.TabIndex = 3;
            // 
            // qUANITITYTextBox
            // 
            this.qUANITITYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sTOCKOUTBindingSource, "QUANITITY", true));
            this.qUANITITYTextBox.Location = new System.Drawing.Point(142, 75);
            this.qUANITITYTextBox.Name = "qUANITITYTextBox";
            this.qUANITITYTextBox.Size = new System.Drawing.Size(233, 20);
            this.qUANITITYTextBox.TabIndex = 5;
            // 
            // pRICEPERUNITTextBox
            // 
            this.pRICEPERUNITTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sTOCKOUTBindingSource, "PRICEPERUNIT", true));
            this.pRICEPERUNITTextBox.Location = new System.Drawing.Point(142, 101);
            this.pRICEPERUNITTextBox.Name = "pRICEPERUNITTextBox";
            this.pRICEPERUNITTextBox.Size = new System.Drawing.Size(233, 20);
            this.pRICEPERUNITTextBox.TabIndex = 7;
            // 
            // tOTALPRICETextBox
            // 
            this.tOTALPRICETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sTOCKOUTBindingSource, "TOTALPRICE", true));
            this.tOTALPRICETextBox.Location = new System.Drawing.Point(142, 127);
            this.tOTALPRICETextBox.Name = "tOTALPRICETextBox";
            this.tOTALPRICETextBox.Size = new System.Drawing.Size(233, 20);
            this.tOTALPRICETextBox.TabIndex = 9;
            // 
            // dATEDateTimePicker
            // 
            this.dATEDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.sTOCKOUTBindingSource, "DATE", true));
            this.dATEDateTimePicker.Location = new System.Drawing.Point(142, 153);
            this.dATEDateTimePicker.Name = "dATEDateTimePicker";
            this.dATEDateTimePicker.Size = new System.Drawing.Size(233, 20);
            this.dATEDateTimePicker.TabIndex = 11;
            // 
            // sERVEBYTextBox
            // 
            this.sERVEBYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sTOCKOUTBindingSource, "SERVEBY", true));
            this.sERVEBYTextBox.Location = new System.Drawing.Point(142, 179);
            this.sERVEBYTextBox.Name = "sERVEBYTextBox";
            this.sERVEBYTextBox.Size = new System.Drawing.Size(233, 20);
            this.sERVEBYTextBox.TabIndex = 13;
            // 
            // sTOCKOUTBindingNavigator
            // 
            this.sTOCKOUTBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.sTOCKOUTBindingNavigator.BindingSource = this.sTOCKOUTBindingSource;
            this.sTOCKOUTBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.sTOCKOUTBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.sTOCKOUTBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.sTOCKOUTBindingNavigatorSaveItem});
            this.sTOCKOUTBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.sTOCKOUTBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.sTOCKOUTBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.sTOCKOUTBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.sTOCKOUTBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.sTOCKOUTBindingNavigator.Name = "sTOCKOUTBindingNavigator";
            this.sTOCKOUTBindingNavigator.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.sTOCKOUTBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.sTOCKOUTBindingNavigator.Size = new System.Drawing.Size(846, 25);
            this.sTOCKOUTBindingNavigator.TabIndex = 1;
            this.sTOCKOUTBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // sTOCKOUTBindingNavigatorSaveItem
            // 
            this.sTOCKOUTBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.sTOCKOUTBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("sTOCKOUTBindingNavigatorSaveItem.Image")));
            this.sTOCKOUTBindingNavigatorSaveItem.Name = "sTOCKOUTBindingNavigatorSaveItem";
            this.sTOCKOUTBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.sTOCKOUTBindingNavigatorSaveItem.Text = "Save Data";
            this.sTOCKOUTBindingNavigatorSaveItem.Click += new System.EventHandler(this.sTOCKOUTBindingNavigatorSaveItem_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.sTOCKOUTDataGridView);
            this.groupBox2.Location = new System.Drawing.Point(14, 364);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(748, 540);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(432, 245);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(79, 20);
            this.textBox4.TabIndex = 10;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(432, 222);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 19);
            this.button4.TabIndex = 9;
            this.button4.Text = "CHANGE";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(429, 199);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(79, 20);
            this.textBox3.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(430, 184);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "CASH GIVEN";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cash",
            "M-PESA",
            "Credit Card"});
            this.comboBox1.Location = new System.Drawing.Point(432, 151);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(95, 21);
            this.comboBox1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(430, 136);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "MODE OF PAYEMENT";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(432, 107);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(79, 20);
            this.textBox2.TabIndex = 4;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(432, 84);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(58, 19);
            this.button3.TabIndex = 3;
            this.button3.Text = "VAT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(432, 50);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(79, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(432, 27);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(58, 19);
            this.button2.TabIndex = 1;
            this.button2.Text = "Total Amount";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // sTOCKOUTDataGridView
            // 
            this.sTOCKOUTDataGridView.AutoGenerateColumns = false;
            this.sTOCKOUTDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.sTOCKOUTDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.sTOCKOUTDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sTOCKOUTDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.sTOCKOUTDataGridView.DataSource = this.sTOCKOUTBindingSource;
            this.sTOCKOUTDataGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sTOCKOUTDataGridView.Location = new System.Drawing.Point(6, 19);
            this.sTOCKOUTDataGridView.Name = "sTOCKOUTDataGridView";
            this.sTOCKOUTDataGridView.Size = new System.Drawing.Size(421, 419);
            this.sTOCKOUTDataGridView.TabIndex = 0;
            this.sTOCKOUTDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.sTOCKOUTDataGridView_CellContentClick);
            // 
            // button5
            // 
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Red;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(348, 299);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(93, 60);
            this.button5.TabIndex = 15;
            this.button5.Text = "Print";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // button6
            // 
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Red;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(102, 294);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(93, 65);
            this.button6.TabIndex = 16;
            this.button6.Text = "Add New";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Red;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(229, 294);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(93, 65);
            this.button7.TabIndex = 17;
            this.button7.Text = "Save";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // sTOCKOUTBindingSource
            // 
            this.sTOCKOUTBindingSource.DataMember = "STOCKOUT";
            this.sTOCKOUTBindingSource.DataSource = this.stock;
            // 
            // stock
            // 
            this.stock.DataSetName = "stock";
            this.stock.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sTOCKOUTTableAdapter
            // 
            this.sTOCKOUTTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CRETableAdapter = null;
            this.tableAdapterManager.DEBTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.stockinTableAdapter = null;
            this.tableAdapterManager.STOCKOUTTableAdapter = this.sTOCKOUTTableAdapter;
            this.tableAdapterManager.UpdateOrder = stocktaking2.stockTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // aCCPERIODLabel
            // 
            aCCPERIODLabel.AutoSize = true;
            aCCPERIODLabel.Location = new System.Drawing.Point(35, 219);
            aCCPERIODLabel.Name = "aCCPERIODLabel";
            aCCPERIODLabel.Size = new System.Drawing.Size(82, 13);
            aCCPERIODLabel.TabIndex = 14;
            aCCPERIODLabel.Text = "ACCPERIOD:";
            // 
            // aCCPERIODTextBox
            // 
            this.aCCPERIODTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sTOCKOUTBindingSource, "ACCPERIOD", true));
            this.aCCPERIODTextBox.Location = new System.Drawing.Point(142, 216);
            this.aCCPERIODTextBox.Name = "aCCPERIODTextBox";
            this.aCCPERIODTextBox.Size = new System.Drawing.Size(233, 20);
            this.aCCPERIODTextBox.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ITEMNUMBER";
            this.dataGridViewTextBoxColumn1.HeaderText = "ITEM NUMBER";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ITEMNAME";
            this.dataGridViewTextBoxColumn2.HeaderText = "ITEM NAME";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ACCPERIOD";
            this.dataGridViewTextBoxColumn3.HeaderText = "ACC PERIOD";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "DATE";
            this.dataGridViewTextBoxColumn6.HeaderText = "DATE";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "QUANITITY";
            this.dataGridViewTextBoxColumn4.HeaderText = "QUANITITY";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "PRICEPERUNIT";
            this.dataGridViewTextBoxColumn5.HeaderText = "PRICE PER UNIT";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "TOTALPRICE";
            this.dataGridViewTextBoxColumn7.HeaderText = "TOTAL PRICE";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "SERVEBY";
            this.dataGridViewTextBoxColumn8.HeaderText = "SERVE BY";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // outstock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Fuchsia;
            this.ClientSize = new System.Drawing.Size(863, 750);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.sTOCKOUTBindingNavigator);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Name = "outstock";
            this.Text = "outstock";
            this.Load += new System.EventHandler(this.outstock_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sTOCKOUTBindingNavigator)).EndInit();
            this.sTOCKOUTBindingNavigator.ResumeLayout(false);
            this.sTOCKOUTBindingNavigator.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sTOCKOUTDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTOCKOUTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private stock stock;
        private System.Windows.Forms.BindingSource sTOCKOUTBindingSource;
        private stockTableAdapters.STOCKOUTTableAdapter sTOCKOUTTableAdapter;
        private stockTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator sTOCKOUTBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton sTOCKOUTBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox iTEMNUMBERTextBox;
        private System.Windows.Forms.TextBox iTEMNAMETextBox;
        private System.Windows.Forms.TextBox qUANITITYTextBox;
        private System.Windows.Forms.TextBox pRICEPERUNITTextBox;
        private System.Windows.Forms.TextBox tOTALPRICETextBox;
        private System.Windows.Forms.DateTimePicker dATEDateTimePicker;
        private System.Windows.Forms.TextBox sERVEBYTextBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView sTOCKOUTDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox aCCPERIODTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
    }
}