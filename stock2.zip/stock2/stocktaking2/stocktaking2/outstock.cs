﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace stocktaking2
{
    public partial class outstock : Form
    {
        public outstock()
        {
            InitializeComponent();
        }

        private void sTOCKOUTBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sTOCKOUTBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void outstock_Load(object sender, EventArgs e)
        {
            this.sTOCKOUTDataGridView.Rows.Clear();

            {
                // TODO: This line of code loads data into the 'stock.STOCKOUT' table. You can move, or remove it, as needed.
                this.sTOCKOUTTableAdapter.Fill(this.stock.STOCKOUT);
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(qUANITITYTextBox.Text) && !string.IsNullOrEmpty(pRICEPERUNITTextBox.Text))
                tOTALPRICETextBox.Text = (Convert.ToInt32(qUANITITYTextBox.Text) *Convert.ToInt32(pRICEPERUNITTextBox.Text)).ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < sTOCKOUTDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(sTOCKOUTDataGridView.Rows[i].Cells[6].Value);
            }

            textBox1.Text = sum.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a;
            bool ia = int.TryParse(textBox1.Text, out a);
            if (ia)
                textBox2.Text = (a * 16 / 100).ToString();
            else textBox2.Text = "in valid";


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int a, b;
            bool ia = int.TryParse(textBox1.Text, out a);
            bool ib = int.TryParse(textBox3.Text, out b);
            if (ia && ib)
                textBox4.Text = (b-a).ToString();
            else textBox4.Text = "in valid";
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap BN = new Bitmap(this.groupBox2.Width, this.groupBox2.Height);
            groupBox2.DrawToBitmap(BN, new Rectangle(0, 0, this.groupBox2.Width, this.groupBox2.Height));
            e.Graphics.DrawImage(BN, 0, 0);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PrintDocument doc = new PrintDocument();
            doc.PrintPage += this.printDocument1_PrintPage;
            PrintDialog dlg = new PrintDialog();
            dlg.Document = doc;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                doc.Print();
            }
        }

        private void sTOCKOUTDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Add New record");
            this.sTOCKOUTBindingSource.AddNew();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sTOCKOUTBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);
            MessageBox.Show("saved");


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
