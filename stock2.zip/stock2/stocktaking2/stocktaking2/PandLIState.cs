﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class PandLIState : Form
    {
        public PandLIState()
        {
            InitializeComponent();
        }

        private void stockinBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockinBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void PandLIState_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.STOCKOUT' table. You can move, or remove it, as needed.
            this.sTOCKOUTTableAdapter.Fill(this.stock.STOCKOUT);
            // TODO: This line of code loads data into the 'stock.stockin' table. You can move, or remove it, as needed.
            this.stockinTableAdapter.Fill(this.stock.stockin);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < stockinDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(stockinDataGridView.Rows[i].Cells[6].Value);
            }

            textBox1.Text = sum.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < sTOCKOUTDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(sTOCKOUTDataGridView.Rows[i].Cells[6].Value);
            }

            textBox2.Text = sum.ToString();
        }

        private void stockinDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void search3ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void search1ToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text) && !string.IsNullOrEmpty(textBox2.Text))
                textBox3.Text = (Convert.ToInt32(textBox2.Text) - Convert.ToInt32(textBox1.Text)).ToString();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
           


            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox4.Clear();
            textBox5.Clear();
            int a, b;
            //string c;
            a = int.Parse(textBox1.Text);
            b = int.Parse(textBox2.Text);

            if (a < b)
                textBox5.Text = "PROFIT"; 
            else if (a > b)
                textBox4.Text = "LOSS";


        }

        private void likeToolStripTextBox_Click(object sender, EventArgs e)
        {
          


        }

        private void search1ToolStripButton1_Click(object sender, EventArgs e)
        {
           

        }

        private void search2ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.stockinTableAdapter.Search2(this.stock.stockin, lIKEToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void search2ToolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void search4ToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void search5ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.sTOCKOUTTableAdapter.Search5(this.stock.STOCKOUT, likeToolStripTextBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sTOCKOUTDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
