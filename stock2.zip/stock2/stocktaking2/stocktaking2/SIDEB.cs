﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class SIDEB : Form
    {
        public SIDEB()
        {
            InitializeComponent();
        }

        private void dEBBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dEBBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void SIDEB_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.DEB' table. You can move, or remove it, as needed.
            this.dEBTableAdapter.Fill(this.stock.DEB);

        }

        private void search1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.dEBTableAdapter.Search1(this.stock.DEB, lIKEToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void searToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

        private void search1ToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
