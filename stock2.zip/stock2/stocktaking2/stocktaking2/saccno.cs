﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class saccno : Form
    {
        public saccno()
        {
            InitializeComponent();
        }

        private void sTOCKOUTBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sTOCKOUTBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void saccno_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.STOCKOUT' table. You can move, or remove it, as needed.
            this.sTOCKOUTTableAdapter.Fill(this.stock.STOCKOUT);

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void sTOCKOUTDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < sTOCKOUTDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(sTOCKOUTDataGridView.Rows[i].Cells[6].Value);
            }

            textBox1.Text = sum.ToString();

        }

        private void search6ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.sTOCKOUTTableAdapter.Search6(this.stock.STOCKOUT, likeToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
