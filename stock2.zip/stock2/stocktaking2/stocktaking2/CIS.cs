﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class CIS : Form
    {
        public CIS()
        {
            InitializeComponent();
        }

        private void cREBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cREBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void CIS_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.CRE' table. You can move, or remove it, as needed.
            this.cRETableAdapter.Fill(this.stock.CRE);

        }

        private void search1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.cRETableAdapter.Search1(this.stock.CRE, likeToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < cREDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(cREDataGridView.Rows[i].Cells[5].Value);
            }

            textBox1.Text = sum.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a;
            bool ai = int.TryParse(textBox1.Text, out a);
            if (ai)
                textBox2.Text = (a * 16 / 100).ToString();
            else textBox2.Text = "in valid";


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}