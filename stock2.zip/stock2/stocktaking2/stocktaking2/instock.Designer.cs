﻿namespace stocktaking2
{
    partial class instock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iTEMNUMBERLabel;
            System.Windows.Forms.Label iTEMNAMELabel;
            System.Windows.Forms.Label qUANITITYLabel;
            System.Windows.Forms.Label pRICE_UNITLabel;
            System.Windows.Forms.Label dATELabel;
            System.Windows.Forms.Label cLEAREDBYLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(instock));
            System.Windows.Forms.Label aCCPERIODLabel;
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.iTEMNUMBERTextBox = new System.Windows.Forms.TextBox();
            this.stockinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stock = new stocktaking2.stock();
            this.iTEMNAMETextBox = new System.Windows.Forms.TextBox();
            this.qUANITITYTextBox = new System.Windows.Forms.TextBox();
            this.pRICE_UNITTextBox = new System.Windows.Forms.TextBox();
            this.tOTALPRICETextBox = new System.Windows.Forms.TextBox();
            this.dATEDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cLEAREDBYTextBox = new System.Windows.Forms.TextBox();
            this.stockinTableAdapter = new stocktaking2.stockTableAdapters.stockinTableAdapter();
            this.tableAdapterManager = new stocktaking2.stockTableAdapters.TableAdapterManager();
            this.stockinBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.stockinBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.aCCPERIODTextBox = new System.Windows.Forms.TextBox();
            iTEMNUMBERLabel = new System.Windows.Forms.Label();
            iTEMNAMELabel = new System.Windows.Forms.Label();
            qUANITITYLabel = new System.Windows.Forms.Label();
            pRICE_UNITLabel = new System.Windows.Forms.Label();
            dATELabel = new System.Windows.Forms.Label();
            cLEAREDBYLabel = new System.Windows.Forms.Label();
            aCCPERIODLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockinBindingNavigator)).BeginInit();
            this.stockinBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // iTEMNUMBERLabel
            // 
            iTEMNUMBERLabel.AutoSize = true;
            iTEMNUMBERLabel.Location = new System.Drawing.Point(6, 48);
            iTEMNUMBERLabel.Name = "iTEMNUMBERLabel";
            iTEMNUMBERLabel.Size = new System.Drawing.Size(117, 16);
            iTEMNUMBERLabel.TabIndex = 0;
            iTEMNUMBERLabel.Text = "ITEM NUMBER:";
            // 
            // iTEMNAMELabel
            // 
            iTEMNAMELabel.AutoSize = true;
            iTEMNAMELabel.Location = new System.Drawing.Point(6, 115);
            iTEMNAMELabel.Name = "iTEMNAMELabel";
            iTEMNAMELabel.Size = new System.Drawing.Size(95, 16);
            iTEMNAMELabel.TabIndex = 2;
            iTEMNAMELabel.Text = "ITEM NAME:";
            // 
            // qUANITITYLabel
            // 
            qUANITITYLabel.AutoSize = true;
            qUANITITYLabel.Location = new System.Drawing.Point(6, 141);
            qUANITITYLabel.Name = "qUANITITYLabel";
            qUANITITYLabel.Size = new System.Drawing.Size(93, 16);
            qUANITITYLabel.TabIndex = 4;
            qUANITITYLabel.Text = "QUANITITY:";
            // 
            // pRICE_UNITLabel
            // 
            pRICE_UNITLabel.AutoSize = true;
            pRICE_UNITLabel.Location = new System.Drawing.Point(6, 167);
            pRICE_UNITLabel.Name = "pRICE_UNITLabel";
            pRICE_UNITLabel.Size = new System.Drawing.Size(98, 16);
            pRICE_UNITLabel.TabIndex = 6;
            pRICE_UNITLabel.Text = "PRICE/UNIT:";
            // 
            // dATELabel
            // 
            dATELabel.AutoSize = true;
            dATELabel.Location = new System.Drawing.Point(6, 220);
            dATELabel.Name = "dATELabel";
            dATELabel.Size = new System.Drawing.Size(53, 16);
            dATELabel.TabIndex = 10;
            dATELabel.Text = "DATE:";
            // 
            // cLEAREDBYLabel
            // 
            cLEAREDBYLabel.AutoSize = true;
            cLEAREDBYLabel.Location = new System.Drawing.Point(6, 245);
            cLEAREDBYLabel.Name = "cLEAREDBYLabel";
            cLEAREDBYLabel.Size = new System.Drawing.Size(102, 16);
            cLEAREDBYLabel.TabIndex = 12;
            cLEAREDBYLabel.Text = "CLEAREDBY:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Fuchsia;
            this.groupBox1.Controls.Add(aCCPERIODLabel);
            this.groupBox1.Controls.Add(this.aCCPERIODTextBox);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(iTEMNUMBERLabel);
            this.groupBox1.Controls.Add(this.iTEMNUMBERTextBox);
            this.groupBox1.Controls.Add(iTEMNAMELabel);
            this.groupBox1.Controls.Add(this.iTEMNAMETextBox);
            this.groupBox1.Controls.Add(qUANITITYLabel);
            this.groupBox1.Controls.Add(this.qUANITITYTextBox);
            this.groupBox1.Controls.Add(pRICE_UNITLabel);
            this.groupBox1.Controls.Add(this.pRICE_UNITTextBox);
            this.groupBox1.Controls.Add(this.tOTALPRICETextBox);
            this.groupBox1.Controls.Add(dATELabel);
            this.groupBox1.Controls.Add(this.dATEDateTimePicker);
            this.groupBox1.Controls.Add(cLEAREDBYLabel);
            this.groupBox1.Controls.Add(this.cLEAREDBYTextBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(628, 394);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Fuchsia;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(6, 188);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 29);
            this.button3.TabIndex = 16;
            this.button3.Text = "TOTAL PRICE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Fuchsia;
            this.button2.Location = new System.Drawing.Point(319, 310);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 58);
            this.button2.TabIndex = 15;
            this.button2.Text = "SAVE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Fuchsia;
            this.button1.Location = new System.Drawing.Point(215, 310);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 58);
            this.button1.TabIndex = 14;
            this.button1.Text = "ADD NEW";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // iTEMNUMBERTextBox
            // 
            this.iTEMNUMBERTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockinBindingSource, "ITEMNUMBER", true));
            this.iTEMNUMBERTextBox.Location = new System.Drawing.Point(125, 45);
            this.iTEMNUMBERTextBox.Name = "iTEMNUMBERTextBox";
            this.iTEMNUMBERTextBox.Size = new System.Drawing.Size(471, 22);
            this.iTEMNUMBERTextBox.TabIndex = 1;
            // 
            // stockinBindingSource
            // 
            this.stockinBindingSource.DataMember = "stockin";
            this.stockinBindingSource.DataSource = this.stock;
            // 
            // stock
            // 
            this.stock.DataSetName = "stock";
            this.stock.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // iTEMNAMETextBox
            // 
            this.iTEMNAMETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockinBindingSource, "ITEMNAME", true));
            this.iTEMNAMETextBox.Location = new System.Drawing.Point(125, 114);
            this.iTEMNAMETextBox.Name = "iTEMNAMETextBox";
            this.iTEMNAMETextBox.Size = new System.Drawing.Size(471, 22);
            this.iTEMNAMETextBox.TabIndex = 3;
            // 
            // qUANITITYTextBox
            // 
            this.qUANITITYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockinBindingSource, "QUANITITY", true));
            this.qUANITITYTextBox.Location = new System.Drawing.Point(125, 138);
            this.qUANITITYTextBox.Name = "qUANITITYTextBox";
            this.qUANITITYTextBox.Size = new System.Drawing.Size(471, 22);
            this.qUANITITYTextBox.TabIndex = 5;
            // 
            // pRICE_UNITTextBox
            // 
            this.pRICE_UNITTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockinBindingSource, "PRICE/UNIT", true));
            this.pRICE_UNITTextBox.Location = new System.Drawing.Point(125, 164);
            this.pRICE_UNITTextBox.Name = "pRICE_UNITTextBox";
            this.pRICE_UNITTextBox.Size = new System.Drawing.Size(471, 22);
            this.pRICE_UNITTextBox.TabIndex = 7;
            // 
            // tOTALPRICETextBox
            // 
            this.tOTALPRICETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockinBindingSource, "TOTALPRICE", true));
            this.tOTALPRICETextBox.Location = new System.Drawing.Point(125, 188);
            this.tOTALPRICETextBox.Name = "tOTALPRICETextBox";
            this.tOTALPRICETextBox.Size = new System.Drawing.Size(471, 22);
            this.tOTALPRICETextBox.TabIndex = 9;
            // 
            // dATEDateTimePicker
            // 
            this.dATEDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.stockinBindingSource, "DATE", true));
            this.dATEDateTimePicker.Location = new System.Drawing.Point(125, 216);
            this.dATEDateTimePicker.Name = "dATEDateTimePicker";
            this.dATEDateTimePicker.Size = new System.Drawing.Size(471, 22);
            this.dATEDateTimePicker.TabIndex = 11;
            // 
            // cLEAREDBYTextBox
            // 
            this.cLEAREDBYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockinBindingSource, "CLEAREDBY", true));
            this.cLEAREDBYTextBox.Location = new System.Drawing.Point(125, 244);
            this.cLEAREDBYTextBox.Name = "cLEAREDBYTextBox";
            this.cLEAREDBYTextBox.Size = new System.Drawing.Size(471, 22);
            this.cLEAREDBYTextBox.TabIndex = 13;
            // 
            // stockinTableAdapter
            // 
            this.stockinTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CRETableAdapter = null;
            this.tableAdapterManager.DEBTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.stockinTableAdapter = this.stockinTableAdapter;
            this.tableAdapterManager.STOCKOUTTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = stocktaking2.stockTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // stockinBindingNavigator
            // 
            this.stockinBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.stockinBindingNavigator.BindingSource = this.stockinBindingSource;
            this.stockinBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.stockinBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.stockinBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.stockinBindingNavigatorSaveItem});
            this.stockinBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.stockinBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.stockinBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.stockinBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.stockinBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.stockinBindingNavigator.Name = "stockinBindingNavigator";
            this.stockinBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.stockinBindingNavigator.Size = new System.Drawing.Size(674, 25);
            this.stockinBindingNavigator.TabIndex = 1;
            this.stockinBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // stockinBindingNavigatorSaveItem
            // 
            this.stockinBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stockinBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("stockinBindingNavigatorSaveItem.Image")));
            this.stockinBindingNavigatorSaveItem.Name = "stockinBindingNavigatorSaveItem";
            this.stockinBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.stockinBindingNavigatorSaveItem.Text = "Save Data";
            this.stockinBindingNavigatorSaveItem.Click += new System.EventHandler(this.stockinBindingNavigatorSaveItem_Click);
            // 
            // aCCPERIODLabel
            // 
            aCCPERIODLabel.AutoSize = true;
            aCCPERIODLabel.Location = new System.Drawing.Point(5, 79);
            aCCPERIODLabel.Name = "aCCPERIODLabel";
            aCCPERIODLabel.Size = new System.Drawing.Size(103, 16);
            aCCPERIODLabel.TabIndex = 16;
            aCCPERIODLabel.Text = "ACC PERIOD:";
            // 
            // aCCPERIODTextBox
            // 
            this.aCCPERIODTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockinBindingSource, "ACCPERIOD", true));
            this.aCCPERIODTextBox.Location = new System.Drawing.Point(125, 73);
            this.aCCPERIODTextBox.Name = "aCCPERIODTextBox";
            this.aCCPERIODTextBox.Size = new System.Drawing.Size(471, 22);
            this.aCCPERIODTextBox.TabIndex = 17;
            // 
            // instock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Fuchsia;
            this.ClientSize = new System.Drawing.Size(674, 483);
            this.Controls.Add(this.stockinBindingNavigator);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.Blue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "instock";
            this.Text = "instock";
            this.Load += new System.EventHandler(this.instock_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockinBindingNavigator)).EndInit();
            this.stockinBindingNavigator.ResumeLayout(false);
            this.stockinBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private stock stock;
        private System.Windows.Forms.BindingSource stockinBindingSource;
        private stockTableAdapters.stockinTableAdapter stockinTableAdapter;
        private stockTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator stockinBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton stockinBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox iTEMNUMBERTextBox;
        private System.Windows.Forms.TextBox iTEMNAMETextBox;
        private System.Windows.Forms.TextBox qUANITITYTextBox;
        private System.Windows.Forms.TextBox pRICE_UNITTextBox;
        private System.Windows.Forms.TextBox tOTALPRICETextBox;
        private System.Windows.Forms.DateTimePicker dATEDateTimePicker;
        private System.Windows.Forms.TextBox cLEAREDBYTextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox aCCPERIODTextBox;
    }
}