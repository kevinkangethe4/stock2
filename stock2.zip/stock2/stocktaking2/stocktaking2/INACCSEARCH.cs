﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class INACCSEARCH : Form
    {
        public INACCSEARCH()
        {
            InitializeComponent();
        }

        private void stockinBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockinBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void INACCSEARCH_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.stockin' table. You can move, or remove it, as needed.
            this.stockinTableAdapter.Fill(this.stock.stockin);

        }

        private void sEARCH11ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.stockinTableAdapter.SEARCH11(this.stock.stockin, lIKEToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < stockinDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(stockinDataGridView.Rows[i].Cells[4].Value);
            }

            textBox1.Text = sum.ToString();
        }
    }
}
