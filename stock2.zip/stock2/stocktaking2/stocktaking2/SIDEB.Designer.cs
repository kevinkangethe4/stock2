﻿namespace stocktaking2
{
    partial class SIDEB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SIDEB));
            this.dEBBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.dEBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stock = new stocktaking2.stock();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.dEBBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.dEBDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dEBTableAdapter = new stocktaking2.stockTableAdapters.DEBTableAdapter();
            this.tableAdapterManager = new stocktaking2.stockTableAdapters.TableAdapterManager();
            this.lIKEToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.lIKEToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.search1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.search1ToolStrip = new System.Windows.Forms.ToolStrip();
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingNavigator)).BeginInit();
            this.dEBBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.search1ToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dEBBindingNavigator
            // 
            this.dEBBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.dEBBindingNavigator.BindingSource = this.dEBBindingSource;
            this.dEBBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.dEBBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.dEBBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.dEBBindingNavigatorSaveItem});
            this.dEBBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.dEBBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.dEBBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.dEBBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.dEBBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.dEBBindingNavigator.Name = "dEBBindingNavigator";
            this.dEBBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.dEBBindingNavigator.Size = new System.Drawing.Size(922, 25);
            this.dEBBindingNavigator.TabIndex = 0;
            this.dEBBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // dEBBindingSource
            // 
            this.dEBBindingSource.DataMember = "DEB";
            this.dEBBindingSource.DataSource = this.stock;
            // 
            // stock
            // 
            this.stock.DataSetName = "stock";
            this.stock.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // dEBBindingNavigatorSaveItem
            // 
            this.dEBBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.dEBBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("dEBBindingNavigatorSaveItem.Image")));
            this.dEBBindingNavigatorSaveItem.Name = "dEBBindingNavigatorSaveItem";
            this.dEBBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.dEBBindingNavigatorSaveItem.Text = "Save Data";
            this.dEBBindingNavigatorSaveItem.Click += new System.EventHandler(this.dEBBindingNavigatorSaveItem_Click);
            // 
            // dEBDataGridView
            // 
            this.dEBDataGridView.AutoGenerateColumns = false;
            this.dEBDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dEBDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dEBDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dEBDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dEBDataGridView.DataSource = this.dEBBindingSource;
            this.dEBDataGridView.GridColor = System.Drawing.Color.Black;
            this.dEBDataGridView.Location = new System.Drawing.Point(28, 38);
            this.dEBDataGridView.Name = "dEBDataGridView";
            this.dEBDataGridView.Size = new System.Drawing.Size(707, 382);
            this.dEBDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "DEBTORId";
            this.dataGridViewTextBoxColumn1.HeaderText = "DEBTORId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NAME";
            this.dataGridViewTextBoxColumn2.HeaderText = "NAME";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ITEM";
            this.dataGridViewTextBoxColumn3.HeaderText = "ITEM";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "QUANITITY";
            this.dataGridViewTextBoxColumn4.HeaderText = "QUANITITY";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "PRICE/UNIT";
            this.dataGridViewTextBoxColumn5.HeaderText = "PRICE/UNIT";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "TOTALPRICE";
            this.dataGridViewTextBoxColumn6.HeaderText = "TOTALPRICE";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "DATE";
            this.dataGridViewTextBoxColumn7.HeaderText = "DATE";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.dEBDataGridView);
            this.groupBox1.ForeColor = System.Drawing.Color.Blue;
            this.groupBox1.Location = new System.Drawing.Point(12, 77);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(755, 420);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // dEBTableAdapter
            // 
            this.dEBTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CRETableAdapter = null;
            this.tableAdapterManager.DEBTableAdapter = this.dEBTableAdapter;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.stockinTableAdapter = null;
            this.tableAdapterManager.STOCKOUTTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = stocktaking2.stockTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // lIKEToolStripLabel
            // 
            this.lIKEToolStripLabel.Name = "lIKEToolStripLabel";
            this.lIKEToolStripLabel.Size = new System.Drawing.Size(150, 34);
            this.lIKEToolStripLabel.Text = "Search Item\'s:";
            // 
            // lIKEToolStripTextBox
            // 
            this.lIKEToolStripTextBox.Name = "lIKEToolStripTextBox";
            this.lIKEToolStripTextBox.Size = new System.Drawing.Size(100, 37);
            // 
            // search1ToolStripButton
            // 
            this.search1ToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.search1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.search1ToolStripButton.Name = "search1ToolStripButton";
            this.search1ToolStripButton.Size = new System.Drawing.Size(82, 34);
            this.search1ToolStripButton.Text = "Search";
            this.search1ToolStripButton.Click += new System.EventHandler(this.search1ToolStripButton_Click);
            // 
            // search1ToolStrip
            // 
            this.search1ToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.search1ToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lIKEToolStripLabel,
            this.lIKEToolStripTextBox,
            this.search1ToolStripButton});
            this.search1ToolStrip.Location = new System.Drawing.Point(0, 25);
            this.search1ToolStrip.Name = "search1ToolStrip";
            this.search1ToolStrip.Size = new System.Drawing.Size(922, 37);
            this.search1ToolStrip.TabIndex = 3;
            this.search1ToolStrip.Text = "search1ToolStrip";
            this.search1ToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.search1ToolStrip_ItemClicked);
            // 
            // SIDEB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(922, 481);
            this.Controls.Add(this.search1ToolStrip);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dEBBindingNavigator);
            this.Name = "SIDEB";
            this.Text = "SIDEB";
            this.Load += new System.EventHandler(this.SIDEB_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingNavigator)).EndInit();
            this.dEBBindingNavigator.ResumeLayout(false);
            this.dEBBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.search1ToolStrip.ResumeLayout(false);
            this.search1ToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private stock stock;
        private System.Windows.Forms.BindingSource dEBBindingSource;
        private stockTableAdapters.DEBTableAdapter dEBTableAdapter;
        private stockTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator dEBBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton dEBBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView dEBDataGridView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripLabel lIKEToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox lIKEToolStripTextBox;
        private System.Windows.Forms.ToolStripButton search1ToolStripButton;
        private System.Windows.Forms.ToolStrip search1ToolStrip;
    }
}