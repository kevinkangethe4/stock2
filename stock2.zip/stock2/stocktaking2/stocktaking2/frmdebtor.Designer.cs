﻿namespace stocktaking2
{
    partial class frmdebtor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmdebtor));
            System.Windows.Forms.Label dEBTORIdLabel;
            System.Windows.Forms.Label nAMELabel;
            System.Windows.Forms.Label iTEMLabel;
            System.Windows.Forms.Label qUANITITYLabel;
            System.Windows.Forms.Label pRICE_UNITLabel;
            System.Windows.Forms.Label tOTALPRICELabel;
            System.Windows.Forms.Label dATELabel;
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stock = new stocktaking2.stock();
            this.dEBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dEBTableAdapter = new stocktaking2.stockTableAdapters.DEBTableAdapter();
            this.tableAdapterManager = new stocktaking2.stockTableAdapters.TableAdapterManager();
            this.dEBBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.dEBBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.dEBTORIdTextBox = new System.Windows.Forms.TextBox();
            this.nAMETextBox = new System.Windows.Forms.TextBox();
            this.iTEMTextBox = new System.Windows.Forms.TextBox();
            this.qUANITITYTextBox = new System.Windows.Forms.TextBox();
            this.pRICE_UNITTextBox = new System.Windows.Forms.TextBox();
            this.tOTALPRICETextBox = new System.Windows.Forms.TextBox();
            this.dATEDateTimePicker = new System.Windows.Forms.DateTimePicker();
            dEBTORIdLabel = new System.Windows.Forms.Label();
            nAMELabel = new System.Windows.Forms.Label();
            iTEMLabel = new System.Windows.Forms.Label();
            qUANITITYLabel = new System.Windows.Forms.Label();
            pRICE_UNITLabel = new System.Windows.Forms.Label();
            tOTALPRICELabel = new System.Windows.Forms.Label();
            dATELabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingNavigator)).BeginInit();
            this.dEBBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(dEBTORIdLabel);
            this.groupBox1.Controls.Add(this.dEBTORIdTextBox);
            this.groupBox1.Controls.Add(nAMELabel);
            this.groupBox1.Controls.Add(this.nAMETextBox);
            this.groupBox1.Controls.Add(iTEMLabel);
            this.groupBox1.Controls.Add(this.iTEMTextBox);
            this.groupBox1.Controls.Add(qUANITITYLabel);
            this.groupBox1.Controls.Add(this.qUANITITYTextBox);
            this.groupBox1.Controls.Add(pRICE_UNITLabel);
            this.groupBox1.Controls.Add(this.pRICE_UNITTextBox);
            this.groupBox1.Controls.Add(tOTALPRICELabel);
            this.groupBox1.Controls.Add(this.tOTALPRICETextBox);
            this.groupBox1.Controls.Add(dATELabel);
            this.groupBox1.Controls.Add(this.dATEDateTimePicker);
            this.groupBox1.Location = new System.Drawing.Point(36, 54);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(935, 494);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // stock
            // 
            this.stock.DataSetName = "stock";
            this.stock.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dEBBindingSource
            // 
            this.dEBBindingSource.DataMember = "DEB";
            this.dEBBindingSource.DataSource = this.stock;
            // 
            // dEBTableAdapter
            // 
            this.dEBTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CRETableAdapter = null;
            this.tableAdapterManager.DEBTableAdapter = this.dEBTableAdapter;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.stockinTableAdapter = null;
            this.tableAdapterManager.STOCKOUTTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = stocktaking2.stockTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dEBBindingNavigator
            // 
            this.dEBBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.dEBBindingNavigator.BindingSource = this.dEBBindingSource;
            this.dEBBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.dEBBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.dEBBindingNavigator.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dEBBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.dEBBindingNavigatorSaveItem});
            this.dEBBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.dEBBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.dEBBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.dEBBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.dEBBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.dEBBindingNavigator.Name = "dEBBindingNavigator";
            this.dEBBindingNavigator.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.dEBBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.dEBBindingNavigator.Size = new System.Drawing.Size(1028, 25);
            this.dEBBindingNavigator.TabIndex = 1;
            this.dEBBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // dEBBindingNavigatorSaveItem
            // 
            this.dEBBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.dEBBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("dEBBindingNavigatorSaveItem.Image")));
            this.dEBBindingNavigatorSaveItem.Name = "dEBBindingNavigatorSaveItem";
            this.dEBBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.dEBBindingNavigatorSaveItem.Text = "Save Data";
            this.dEBBindingNavigatorSaveItem.Click += new System.EventHandler(this.dEBBindingNavigatorSaveItem_Click);
            // 
            // dEBTORIdLabel
            // 
            dEBTORIdLabel.AutoSize = true;
            dEBTORIdLabel.Location = new System.Drawing.Point(25, 98);
            dEBTORIdLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            dEBTORIdLabel.Name = "dEBTORIdLabel";
            dEBTORIdLabel.Size = new System.Drawing.Size(94, 16);
            dEBTORIdLabel.TabIndex = 0;
            dEBTORIdLabel.Text = "DEBTOR ID:";
            // 
            // dEBTORIdTextBox
            // 
            this.dEBTORIdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dEBBindingSource, "DEBTORId", true));
            this.dEBTORIdTextBox.Location = new System.Drawing.Point(140, 98);
            this.dEBTORIdTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dEBTORIdTextBox.Name = "dEBTORIdTextBox";
            this.dEBTORIdTextBox.Size = new System.Drawing.Size(528, 22);
            this.dEBTORIdTextBox.TabIndex = 1;
            // 
            // nAMELabel
            // 
            nAMELabel.AutoSize = true;
            nAMELabel.Location = new System.Drawing.Point(25, 130);
            nAMELabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            nAMELabel.Name = "nAMELabel";
            nAMELabel.Size = new System.Drawing.Size(55, 16);
            nAMELabel.TabIndex = 2;
            nAMELabel.Text = "NAME:";
            // 
            // nAMETextBox
            // 
            this.nAMETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dEBBindingSource, "NAME", true));
            this.nAMETextBox.Location = new System.Drawing.Point(140, 130);
            this.nAMETextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nAMETextBox.Name = "nAMETextBox";
            this.nAMETextBox.Size = new System.Drawing.Size(528, 22);
            this.nAMETextBox.TabIndex = 3;
            // 
            // iTEMLabel
            // 
            iTEMLabel.AutoSize = true;
            iTEMLabel.Location = new System.Drawing.Point(25, 162);
            iTEMLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            iTEMLabel.Name = "iTEMLabel";
            iTEMLabel.Size = new System.Drawing.Size(48, 16);
            iTEMLabel.TabIndex = 4;
            iTEMLabel.Text = "ITEM:";
            // 
            // iTEMTextBox
            // 
            this.iTEMTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dEBBindingSource, "ITEM", true));
            this.iTEMTextBox.Location = new System.Drawing.Point(140, 162);
            this.iTEMTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iTEMTextBox.Name = "iTEMTextBox";
            this.iTEMTextBox.Size = new System.Drawing.Size(528, 22);
            this.iTEMTextBox.TabIndex = 5;
            // 
            // qUANITITYLabel
            // 
            qUANITITYLabel.AutoSize = true;
            qUANITITYLabel.Location = new System.Drawing.Point(25, 194);
            qUANITITYLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            qUANITITYLabel.Name = "qUANITITYLabel";
            qUANITITYLabel.Size = new System.Drawing.Size(93, 16);
            qUANITITYLabel.TabIndex = 6;
            qUANITITYLabel.Text = "QUANITITY:";
            // 
            // qUANITITYTextBox
            // 
            this.qUANITITYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dEBBindingSource, "QUANITITY", true));
            this.qUANITITYTextBox.Location = new System.Drawing.Point(140, 194);
            this.qUANITITYTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qUANITITYTextBox.Name = "qUANITITYTextBox";
            this.qUANITITYTextBox.Size = new System.Drawing.Size(528, 22);
            this.qUANITITYTextBox.TabIndex = 7;
            // 
            // pRICE_UNITLabel
            // 
            pRICE_UNITLabel.AutoSize = true;
            pRICE_UNITLabel.Location = new System.Drawing.Point(25, 226);
            pRICE_UNITLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            pRICE_UNITLabel.Name = "pRICE_UNITLabel";
            pRICE_UNITLabel.Size = new System.Drawing.Size(98, 16);
            pRICE_UNITLabel.TabIndex = 8;
            pRICE_UNITLabel.Text = "PRICE/UNIT:";
            // 
            // pRICE_UNITTextBox
            // 
            this.pRICE_UNITTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dEBBindingSource, "PRICE/UNIT", true));
            this.pRICE_UNITTextBox.Location = new System.Drawing.Point(140, 240);
            this.pRICE_UNITTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pRICE_UNITTextBox.Name = "pRICE_UNITTextBox";
            this.pRICE_UNITTextBox.Size = new System.Drawing.Size(528, 22);
            this.pRICE_UNITTextBox.TabIndex = 9;
            // 
            // tOTALPRICELabel
            // 
            tOTALPRICELabel.AutoSize = true;
            tOTALPRICELabel.Location = new System.Drawing.Point(25, 258);
            tOTALPRICELabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            tOTALPRICELabel.Name = "tOTALPRICELabel";
            tOTALPRICELabel.Size = new System.Drawing.Size(106, 16);
            tOTALPRICELabel.TabIndex = 10;
            tOTALPRICELabel.Text = "TOTALPRICE:";
            // 
            // tOTALPRICETextBox
            // 
            this.tOTALPRICETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dEBBindingSource, "TOTALPRICE", true));
            this.tOTALPRICETextBox.Location = new System.Drawing.Point(140, 272);
            this.tOTALPRICETextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tOTALPRICETextBox.Name = "tOTALPRICETextBox";
            this.tOTALPRICETextBox.Size = new System.Drawing.Size(528, 22);
            this.tOTALPRICETextBox.TabIndex = 11;
            // 
            // dATELabel
            // 
            dATELabel.AutoSize = true;
            dATELabel.Location = new System.Drawing.Point(25, 292);
            dATELabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            dATELabel.Name = "dATELabel";
            dATELabel.Size = new System.Drawing.Size(53, 16);
            dATELabel.TabIndex = 12;
            dATELabel.Text = "DATE:";
            // 
            // dATEDateTimePicker
            // 
            this.dATEDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.dEBBindingSource, "DATE", true));
            this.dATEDateTimePicker.Location = new System.Drawing.Point(140, 302);
            this.dATEDateTimePicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dATEDateTimePicker.Name = "dATEDateTimePicker";
            this.dATEDateTimePicker.Size = new System.Drawing.Size(528, 22);
            this.dATEDateTimePicker.TabIndex = 13;
            // 
            // frmdebtor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Fuchsia;
            this.ClientSize = new System.Drawing.Size(1028, 571);
            this.Controls.Add(this.dEBBindingNavigator);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Navy;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmdebtor";
            this.Text = "frmdebtor";
            this.Load += new System.EventHandler(this.frmdebtor_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBBindingNavigator)).EndInit();
            this.dEBBindingNavigator.ResumeLayout(false);
            this.dEBBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private stock stock;
        private System.Windows.Forms.BindingSource dEBBindingSource;
        private stockTableAdapters.DEBTableAdapter dEBTableAdapter;
        private stockTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator dEBBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton dEBBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox dEBTORIdTextBox;
        private System.Windows.Forms.TextBox nAMETextBox;
        private System.Windows.Forms.TextBox iTEMTextBox;
        private System.Windows.Forms.TextBox qUANITITYTextBox;
        private System.Windows.Forms.TextBox pRICE_UNITTextBox;
        private System.Windows.Forms.TextBox tOTALPRICETextBox;
        private System.Windows.Forms.DateTimePicker dATEDateTimePicker;
    }
}