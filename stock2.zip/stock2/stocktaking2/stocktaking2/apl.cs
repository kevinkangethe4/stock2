﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stocktaking2
{
    public partial class apl : Form
    {
        public apl()
        {
            InitializeComponent();
        }

        private void stockinBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockinBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stock);

        }

        private void apl_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stock.STOCKOUT' table. You can move, or remove it, as needed.
            this.sTOCKOUTTableAdapter.Fill(this.stock.STOCKOUT);
            // TODO: This line of code loads data into the 'stock.stockin' table. You can move, or remove it, as needed.
            this.stockinTableAdapter.Fill(this.stock.stockin);

        }

        private void search3ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.stockinTableAdapter.search3(this.stock.stockin, likeToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void search7ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.sTOCKOUTTableAdapter.search7(this.stock.STOCKOUT, likeToolStripTextBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

            int sum = 0;
            for (int i = 0; i < stockinDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(stockinDataGridView.Rows[i].Cells[6].Value);
            }

            textBox1.Text = sum.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text) && !string.IsNullOrEmpty(textBox2.Text))
                textBox3.Text = (Convert.ToInt32(textBox2.Text) - Convert.ToInt32(textBox1.Text)).ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < sTOCKOUTDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(sTOCKOUTDataGridView.Rows[i].Cells[6].Value);
            }

            textBox2.Text = sum.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox4.Clear();
            textBox5.Clear();
            int a, b;
            //string c;
            a = int.Parse(textBox1.Text);
            b = int.Parse(textBox2.Text);

            if (a < b)
                textBox5.Text = "PROFIT";
            else if (a > b)
                textBox4.Text = "LOSS";
        }
    }
}
