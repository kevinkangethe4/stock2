﻿namespace stocktaking2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sTOCKINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOCKINFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHITEMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOCKOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOCKOUTFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHITEMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchByDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEBTORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEBTORFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEBTORREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHDEBTORBYITEMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cREDITORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cREDITORFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cREDITORSREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHBYITEMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sTOCKINToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOCKINFORMToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHBYITEMToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHBYDATEToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOCKOUTToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bYITEMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bYDATEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROFITANDLOSSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTATEMENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEBTORSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEBTORSFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.iTEMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dATEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cREDITORSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cREDITORSFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.nAMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iTEMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.Lime;
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTOCKINToolStripMenuItem,
            this.sTOCKOUTToolStripMenuItem,
            this.pLToolStripMenuItem,
            this.dEBTORToolStripMenuItem,
            this.cREDITORToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(959, 85);
            this.menuStrip1.Stretch = false;
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // sTOCKINToolStripMenuItem
            // 
            this.sTOCKINToolStripMenuItem.BackgroundImage = global::stocktaking2.Properties.Resources.AG00090_;
            this.sTOCKINToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sTOCKINToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTOCKINFORMToolStripMenuItem,
            this.sEARCHITEMToolStripMenuItem,
            this.sEToolStripMenuItem,
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem});
            this.sTOCKINToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sTOCKINToolStripMenuItem.Image")));
            this.sTOCKINToolStripMenuItem.Name = "sTOCKINToolStripMenuItem";
            this.sTOCKINToolStripMenuItem.Size = new System.Drawing.Size(160, 81);
            this.sTOCKINToolStripMenuItem.Text = "STOCK IN";
            // 
            // sTOCKINFORMToolStripMenuItem
            // 
            this.sTOCKINFORMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sTOCKINFORMToolStripMenuItem.BackgroundImage = global::stocktaking2.Properties.Resources.AG00090_;
            this.sTOCKINFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sTOCKINFORMToolStripMenuItem.ForeColor = System.Drawing.Color.Purple;
            this.sTOCKINFORMToolStripMenuItem.Name = "sTOCKINFORMToolStripMenuItem";
            this.sTOCKINFORMToolStripMenuItem.Size = new System.Drawing.Size(460, 34);
            this.sTOCKINFORMToolStripMenuItem.Text = "STOCK IN FORM";
            this.sTOCKINFORMToolStripMenuItem.Click += new System.EventHandler(this.sTOCKINFORMToolStripMenuItem_Click);
            // 
            // sEARCHITEMToolStripMenuItem
            // 
            this.sEARCHITEMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sEARCHITEMToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sEARCHITEMToolStripMenuItem.BackgroundImage")));
            this.sEARCHITEMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sEARCHITEMToolStripMenuItem.ForeColor = System.Drawing.Color.Purple;
            this.sEARCHITEMToolStripMenuItem.Name = "sEARCHITEMToolStripMenuItem";
            this.sEARCHITEMToolStripMenuItem.Size = new System.Drawing.Size(460, 34);
            this.sEARCHITEMToolStripMenuItem.Text = "SEARCH BY  ITEM NAME";
            this.sEARCHITEMToolStripMenuItem.Click += new System.EventHandler(this.sEARCHITEMToolStripMenuItem_Click);
            // 
            // sEToolStripMenuItem
            // 
            this.sEToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sEToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sEToolStripMenuItem.BackgroundImage")));
            this.sEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.sEToolStripMenuItem.ForeColor = System.Drawing.Color.Purple;
            this.sEToolStripMenuItem.Name = "sEToolStripMenuItem";
            this.sEToolStripMenuItem.Size = new System.Drawing.Size(460, 34);
            this.sEToolStripMenuItem.Text = "SEARCH BY DATE";
            this.sEToolStripMenuItem.Click += new System.EventHandler(this.sEToolStripMenuItem_Click);
            // 
            // sEARCHACCOUNTINGPERIODToolStripMenuItem
            // 
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sEARCHACCOUNTINGPERIODToolStripMenuItem.BackgroundImage")));
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem.ForeColor = System.Drawing.Color.Purple;
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem.Name = "sEARCHACCOUNTINGPERIODToolStripMenuItem";
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem.Size = new System.Drawing.Size(460, 34);
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem.Text = "SEARCH ACCOUNTING PERIOD";
            this.sEARCHACCOUNTINGPERIODToolStripMenuItem.Click += new System.EventHandler(this.sEARCHACCOUNTINGPERIODToolStripMenuItem_Click);
            // 
            // sTOCKOUTToolStripMenuItem
            // 
            this.sTOCKOUTToolStripMenuItem.BackgroundImage = global::stocktaking2.Properties.Resources.AG00092_;
            this.sTOCKOUTToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sTOCKOUTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTOCKOUTFORMToolStripMenuItem,
            this.sEARCHITEMSToolStripMenuItem,
            this.searchByDateToolStripMenuItem,
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem});
            this.sTOCKOUTToolStripMenuItem.Name = "sTOCKOUTToolStripMenuItem";
            this.sTOCKOUTToolStripMenuItem.Size = new System.Drawing.Size(164, 81);
            this.sTOCKOUTToolStripMenuItem.Text = "STOCK OUT";
            // 
            // sTOCKOUTFORMToolStripMenuItem
            // 
            this.sTOCKOUTFORMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sTOCKOUTFORMToolStripMenuItem.BackgroundImage = global::stocktaking2.Properties.Resources.AG00090_;
            this.sTOCKOUTFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.sTOCKOUTFORMToolStripMenuItem.ForeColor = System.Drawing.Color.Purple;
            this.sTOCKOUTFORMToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sTOCKOUTFORMToolStripMenuItem.Image")));
            this.sTOCKOUTFORMToolStripMenuItem.Name = "sTOCKOUTFORMToolStripMenuItem";
            this.sTOCKOUTFORMToolStripMenuItem.Size = new System.Drawing.Size(450, 34);
            this.sTOCKOUTFORMToolStripMenuItem.Text = "STOCK OUT FORM";
            this.sTOCKOUTFORMToolStripMenuItem.Click += new System.EventHandler(this.sTOCKOUTFORMToolStripMenuItem_Click);
            // 
            // sEARCHITEMSToolStripMenuItem
            // 
            this.sEARCHITEMSToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sEARCHITEMSToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sEARCHITEMSToolStripMenuItem.BackgroundImage")));
            this.sEARCHITEMSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sEARCHITEMSToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHITEMSToolStripMenuItem.Name = "sEARCHITEMSToolStripMenuItem";
            this.sEARCHITEMSToolStripMenuItem.Size = new System.Drawing.Size(450, 34);
            this.sEARCHITEMSToolStripMenuItem.Text = "SEARCH ITEMS";
            this.sEARCHITEMSToolStripMenuItem.Click += new System.EventHandler(this.sEARCHITEMSToolStripMenuItem_Click);
            // 
            // searchByDateToolStripMenuItem
            // 
            this.searchByDateToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.searchByDateToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("searchByDateToolStripMenuItem.BackgroundImage")));
            this.searchByDateToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.searchByDateToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.searchByDateToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("searchByDateToolStripMenuItem.Image")));
            this.searchByDateToolStripMenuItem.Name = "searchByDateToolStripMenuItem";
            this.searchByDateToolStripMenuItem.Size = new System.Drawing.Size(450, 34);
            this.searchByDateToolStripMenuItem.Text = "SEARCH BY DATE";
            this.searchByDateToolStripMenuItem.Click += new System.EventHandler(this.searchByDateToolStripMenuItem_Click);
            // 
            // sEARCHBYACCOUNTPERIODToolStripMenuItem
            // 
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sEARCHBYACCOUNTPERIODToolStripMenuItem.BackgroundImage")));
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem.Name = "sEARCHBYACCOUNTPERIODToolStripMenuItem";
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem.Size = new System.Drawing.Size(450, 34);
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem.Text = "SEARCH BY ACCOUNT PERIOD";
            this.sEARCHBYACCOUNTPERIODToolStripMenuItem.Click += new System.EventHandler(this.sEARCHBYACCOUNTPERIODToolStripMenuItem_Click);
            // 
            // pLToolStripMenuItem
            // 
            this.pLToolStripMenuItem.BackgroundImage = global::stocktaking2.Properties.Resources.AG00120_;
            this.pLToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pLREPORTToolStripMenuItem,
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem});
            this.pLToolStripMenuItem.Name = "pLToolStripMenuItem";
            this.pLToolStripMenuItem.Size = new System.Drawing.Size(159, 81);
            this.pLToolStripMenuItem.Text = "Profit &  loss";
            // 
            // pLREPORTToolStripMenuItem
            // 
            this.pLREPORTToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.pLREPORTToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pLREPORTToolStripMenuItem.BackgroundImage")));
            this.pLREPORTToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pLREPORTToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pLREPORTToolStripMenuItem.Name = "pLREPORTToolStripMenuItem";
            this.pLREPORTToolStripMenuItem.Size = new System.Drawing.Size(488, 34);
            this.pLREPORTToolStripMenuItem.Text = "P&L REPORT BY ITEM\'S NAME";
            this.pLREPORTToolStripMenuItem.Click += new System.EventHandler(this.pLREPORTToolStripMenuItem_Click);
            // 
            // pLREPORTBYACCOUNTPERIODToolStripMenuItem
            // 
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pLREPORTBYACCOUNTPERIODToolStripMenuItem.BackgroundImage")));
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.Name = "pLREPORTBYACCOUNTPERIODToolStripMenuItem";
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.Size = new System.Drawing.Size(488, 34);
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.Text = "P&L REPORT BY ACCOUNT PERIOD";
            this.pLREPORTBYACCOUNTPERIODToolStripMenuItem.Click += new System.EventHandler(this.pLREPORTBYACCOUNTPERIODToolStripMenuItem_Click);
            // 
            // dEBTORToolStripMenuItem
            // 
            this.dEBTORToolStripMenuItem.BackgroundImage = global::stocktaking2.Properties.Resources._9;
            this.dEBTORToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dEBTORToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dEBTORFORMToolStripMenuItem,
            this.dEBTORREPORTToolStripMenuItem,
            this.sEARCHDEBTORBYITEMToolStripMenuItem});
            this.dEBTORToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dEBTORToolStripMenuItem.Name = "dEBTORToolStripMenuItem";
            this.dEBTORToolStripMenuItem.Size = new System.Drawing.Size(167, 81);
            this.dEBTORToolStripMenuItem.Text = "DEBTOR\'S";
            this.dEBTORToolStripMenuItem.Click += new System.EventHandler(this.dEBTORToolStripMenuItem_Click);
            // 
            // dEBTORFORMToolStripMenuItem
            // 
            this.dEBTORFORMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.dEBTORFORMToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("dEBTORFORMToolStripMenuItem.BackgroundImage")));
            this.dEBTORFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dEBTORFORMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dEBTORFORMToolStripMenuItem.Name = "dEBTORFORMToolStripMenuItem";
            this.dEBTORFORMToolStripMenuItem.Size = new System.Drawing.Size(464, 44);
            this.dEBTORFORMToolStripMenuItem.Text = "DEBTOR FORM";
            this.dEBTORFORMToolStripMenuItem.Click += new System.EventHandler(this.dEBTORFORMToolStripMenuItem_Click);
            // 
            // dEBTORREPORTToolStripMenuItem
            // 
            this.dEBTORREPORTToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.dEBTORREPORTToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("dEBTORREPORTToolStripMenuItem.BackgroundImage")));
            this.dEBTORREPORTToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dEBTORREPORTToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dEBTORREPORTToolStripMenuItem.Name = "dEBTORREPORTToolStripMenuItem";
            this.dEBTORREPORTToolStripMenuItem.Size = new System.Drawing.Size(464, 44);
            this.dEBTORREPORTToolStripMenuItem.Text = "SEARCH DEBTOR BY NAME";
            this.dEBTORREPORTToolStripMenuItem.Click += new System.EventHandler(this.dEBTORREPORTToolStripMenuItem_Click);
            // 
            // sEARCHDEBTORBYITEMToolStripMenuItem
            // 
            this.sEARCHDEBTORBYITEMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sEARCHDEBTORBYITEMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHDEBTORBYITEMToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sEARCHDEBTORBYITEMToolStripMenuItem.Image")));
            this.sEARCHDEBTORBYITEMToolStripMenuItem.Name = "sEARCHDEBTORBYITEMToolStripMenuItem";
            this.sEARCHDEBTORBYITEMToolStripMenuItem.Size = new System.Drawing.Size(464, 44);
            this.sEARCHDEBTORBYITEMToolStripMenuItem.Text = "SEARCH DEBTOR BY ITEM";
            this.sEARCHDEBTORBYITEMToolStripMenuItem.Click += new System.EventHandler(this.sEARCHDEBTORBYITEMToolStripMenuItem_Click);
            // 
            // cREDITORToolStripMenuItem
            // 
            this.cREDITORToolStripMenuItem.BackgroundImage = global::stocktaking2.Properties.Resources.fij;
            this.cREDITORToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cREDITORToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cREDITORFORMToolStripMenuItem,
            this.cREDITORSREPORTToolStripMenuItem,
            this.sEARCHBYITEMToolStripMenuItem});
            this.cREDITORToolStripMenuItem.Name = "cREDITORToolStripMenuItem";
            this.cREDITORToolStripMenuItem.Size = new System.Drawing.Size(153, 81);
            this.cREDITORToolStripMenuItem.Text = "CREDITOR";
            this.cREDITORToolStripMenuItem.Click += new System.EventHandler(this.cREDITORToolStripMenuItem_Click);
            // 
            // cREDITORFORMToolStripMenuItem
            // 
            this.cREDITORFORMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.cREDITORFORMToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cREDITORFORMToolStripMenuItem.BackgroundImage")));
            this.cREDITORFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cREDITORFORMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.cREDITORFORMToolStripMenuItem.Name = "cREDITORFORMToolStripMenuItem";
            this.cREDITORFORMToolStripMenuItem.Size = new System.Drawing.Size(457, 34);
            this.cREDITORFORMToolStripMenuItem.Text = "CREDITOR FORM";
            this.cREDITORFORMToolStripMenuItem.Click += new System.EventHandler(this.cREDITORFORMToolStripMenuItem_Click);
            // 
            // cREDITORSREPORTToolStripMenuItem
            // 
            this.cREDITORSREPORTToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.cREDITORSREPORTToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cREDITORSREPORTToolStripMenuItem.BackgroundImage")));
            this.cREDITORSREPORTToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cREDITORSREPORTToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.cREDITORSREPORTToolStripMenuItem.Name = "cREDITORSREPORTToolStripMenuItem";
            this.cREDITORSREPORTToolStripMenuItem.Size = new System.Drawing.Size(457, 34);
            this.cREDITORSREPORTToolStripMenuItem.Text = "SEARCH BY CREDITOR\'S NAME";
            this.cREDITORSREPORTToolStripMenuItem.Click += new System.EventHandler(this.cREDITORSREPORTToolStripMenuItem_Click);
            // 
            // sEARCHBYITEMToolStripMenuItem
            // 
            this.sEARCHBYITEMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sEARCHBYITEMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHBYITEMToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sEARCHBYITEMToolStripMenuItem.Image")));
            this.sEARCHBYITEMToolStripMenuItem.Name = "sEARCHBYITEMToolStripMenuItem";
            this.sEARCHBYITEMToolStripMenuItem.Size = new System.Drawing.Size(457, 34);
            this.sEARCHBYITEMToolStripMenuItem.Text = "SEARCH BY ITEM";
            this.sEARCHBYITEMToolStripMenuItem.Click += new System.EventHandler(this.sEARCHBYITEMToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.Color.Lime;
            this.contextMenuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTOCKINToolStripMenuItem1,
            this.sTOCKOUTToolStripMenuItem1,
            this.pROFITANDLOSSToolStripMenuItem,
            this.dEBTORSToolStripMenuItem,
            this.cREDITORSToolStripMenuItem,
            this.eXITToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(217, 160);
            // 
            // sTOCKINToolStripMenuItem1
            // 
            this.sTOCKINToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTOCKINFORMToolStripMenuItem1,
            this.sEARCHToolStripMenuItem});
            this.sTOCKINToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sTOCKINToolStripMenuItem1.Image = global::stocktaking2.Properties.Resources.AG00090_;
            this.sTOCKINToolStripMenuItem1.Name = "sTOCKINToolStripMenuItem1";
            this.sTOCKINToolStripMenuItem1.Size = new System.Drawing.Size(216, 26);
            this.sTOCKINToolStripMenuItem1.Text = "STOCK IN";
            // 
            // sTOCKINFORMToolStripMenuItem1
            // 
            this.sTOCKINFORMToolStripMenuItem1.BackColor = System.Drawing.Color.Lime;
            this.sTOCKINFORMToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sTOCKINFORMToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("sTOCKINFORMToolStripMenuItem1.Image")));
            this.sTOCKINFORMToolStripMenuItem1.Name = "sTOCKINFORMToolStripMenuItem1";
            this.sTOCKINFORMToolStripMenuItem1.Size = new System.Drawing.Size(201, 26);
            this.sTOCKINFORMToolStripMenuItem1.Text = "STOCK IN FORM";
            this.sTOCKINFORMToolStripMenuItem1.Click += new System.EventHandler(this.sTOCKINFORMToolStripMenuItem1_Click);
            // 
            // sEARCHToolStripMenuItem
            // 
            this.sEARCHToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sEARCHToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sEARCHBYITEMToolStripMenuItem1,
            this.sEARCHBYDATEToolStripMenuItem1});
            this.sEARCHToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sEARCHToolStripMenuItem.Image")));
            this.sEARCHToolStripMenuItem.Name = "sEARCHToolStripMenuItem";
            this.sEARCHToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.sEARCHToolStripMenuItem.Text = "SEARCH";
            // 
            // sEARCHBYITEMToolStripMenuItem1
            // 
            this.sEARCHBYITEMToolStripMenuItem1.BackColor = System.Drawing.Color.Lime;
            this.sEARCHBYITEMToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHBYITEMToolStripMenuItem1.Name = "sEARCHBYITEMToolStripMenuItem1";
            this.sEARCHBYITEMToolStripMenuItem1.Size = new System.Drawing.Size(211, 26);
            this.sEARCHBYITEMToolStripMenuItem1.Text = "SEARCH BY  ITEM";
            this.sEARCHBYITEMToolStripMenuItem1.Click += new System.EventHandler(this.sEARCHBYITEMToolStripMenuItem1_Click);
            // 
            // sEARCHBYDATEToolStripMenuItem1
            // 
            this.sEARCHBYDATEToolStripMenuItem1.BackColor = System.Drawing.Color.Lime;
            this.sEARCHBYDATEToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHBYDATEToolStripMenuItem1.Name = "sEARCHBYDATEToolStripMenuItem1";
            this.sEARCHBYDATEToolStripMenuItem1.Size = new System.Drawing.Size(211, 26);
            this.sEARCHBYDATEToolStripMenuItem1.Text = "SEARCH BY DATE";
            this.sEARCHBYDATEToolStripMenuItem1.Click += new System.EventHandler(this.sEARCHBYDATEToolStripMenuItem1_Click);
            // 
            // sTOCKOUTToolStripMenuItem1
            // 
            this.sTOCKOUTToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fORMToolStripMenuItem,
            this.sEARCHToolStripMenuItem1});
            this.sTOCKOUTToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sTOCKOUTToolStripMenuItem1.Image = global::stocktaking2.Properties.Resources.AG00092_;
            this.sTOCKOUTToolStripMenuItem1.Name = "sTOCKOUTToolStripMenuItem1";
            this.sTOCKOUTToolStripMenuItem1.Size = new System.Drawing.Size(216, 26);
            this.sTOCKOUTToolStripMenuItem1.Text = "STOCK OUT";
            // 
            // fORMToolStripMenuItem
            // 
            this.fORMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.fORMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.fORMToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fORMToolStripMenuItem.Image")));
            this.fORMToolStripMenuItem.Name = "fORMToolStripMenuItem";
            this.fORMToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.fORMToolStripMenuItem.Text = "STOCK OUT FORM";
            this.fORMToolStripMenuItem.Click += new System.EventHandler(this.fORMToolStripMenuItem_Click);
            // 
            // sEARCHToolStripMenuItem1
            // 
            this.sEARCHToolStripMenuItem1.BackColor = System.Drawing.Color.Lime;
            this.sEARCHToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bYITEMToolStripMenuItem,
            this.bYDATEToolStripMenuItem});
            this.sEARCHToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("sEARCHToolStripMenuItem1.Image")));
            this.sEARCHToolStripMenuItem1.Name = "sEARCHToolStripMenuItem1";
            this.sEARCHToolStripMenuItem1.Size = new System.Drawing.Size(216, 26);
            this.sEARCHToolStripMenuItem1.Text = "SEARCH";
            // 
            // bYITEMToolStripMenuItem
            // 
            this.bYITEMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.bYITEMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bYITEMToolStripMenuItem.Name = "bYITEMToolStripMenuItem";
            this.bYITEMToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.bYITEMToolStripMenuItem.Text = "BY ITEM";
            this.bYITEMToolStripMenuItem.Click += new System.EventHandler(this.bYITEMToolStripMenuItem_Click);
            // 
            // bYDATEToolStripMenuItem
            // 
            this.bYDATEToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.bYDATEToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bYDATEToolStripMenuItem.Name = "bYDATEToolStripMenuItem";
            this.bYDATEToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.bYDATEToolStripMenuItem.Text = "BY DATE";
            this.bYDATEToolStripMenuItem.Click += new System.EventHandler(this.bYDATEToolStripMenuItem_Click);
            // 
            // pROFITANDLOSSToolStripMenuItem
            // 
            this.pROFITANDLOSSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTATEMENTToolStripMenuItem});
            this.pROFITANDLOSSToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pROFITANDLOSSToolStripMenuItem.Image = global::stocktaking2.Properties.Resources.AG00120_;
            this.pROFITANDLOSSToolStripMenuItem.Name = "pROFITANDLOSSToolStripMenuItem";
            this.pROFITANDLOSSToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.pROFITANDLOSSToolStripMenuItem.Text = "PROFIT AND LOSS";
            // 
            // sTATEMENTToolStripMenuItem
            // 
            this.sTATEMENTToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.sTATEMENTToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sTATEMENTToolStripMenuItem.Image = global::stocktaking2.Properties.Resources.AG00120_;
            this.sTATEMENTToolStripMenuItem.Name = "sTATEMENTToolStripMenuItem";
            this.sTATEMENTToolStripMenuItem.Size = new System.Drawing.Size(173, 26);
            this.sTATEMENTToolStripMenuItem.Text = "STATEMENT";
            this.sTATEMENTToolStripMenuItem.Click += new System.EventHandler(this.sTATEMENTToolStripMenuItem_Click);
            // 
            // dEBTORSToolStripMenuItem
            // 
            this.dEBTORSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dEBTORSFORMToolStripMenuItem,
            this.sEARCHToolStripMenuItem2});
            this.dEBTORSToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dEBTORSToolStripMenuItem.Image = global::stocktaking2.Properties.Resources._9;
            this.dEBTORSToolStripMenuItem.Name = "dEBTORSToolStripMenuItem";
            this.dEBTORSToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.dEBTORSToolStripMenuItem.Text = "DEBTOR\'S";
            // 
            // dEBTORSFORMToolStripMenuItem
            // 
            this.dEBTORSFORMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.dEBTORSFORMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dEBTORSFORMToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("dEBTORSFORMToolStripMenuItem.Image")));
            this.dEBTORSFORMToolStripMenuItem.Name = "dEBTORSFORMToolStripMenuItem";
            this.dEBTORSFORMToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.dEBTORSFORMToolStripMenuItem.Text = "DEBTOR\'S FORM";
            this.dEBTORSFORMToolStripMenuItem.Click += new System.EventHandler(this.dEBTORSFORMToolStripMenuItem_Click);
            // 
            // sEARCHToolStripMenuItem2
            // 
            this.sEARCHToolStripMenuItem2.BackColor = System.Drawing.Color.Lime;
            this.sEARCHToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iTEMToolStripMenuItem,
            this.dATEToolStripMenuItem});
            this.sEARCHToolStripMenuItem2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("sEARCHToolStripMenuItem2.Image")));
            this.sEARCHToolStripMenuItem2.Name = "sEARCHToolStripMenuItem2";
            this.sEARCHToolStripMenuItem2.Size = new System.Drawing.Size(205, 26);
            this.sEARCHToolStripMenuItem2.Text = "SEARCH BY";
            // 
            // iTEMToolStripMenuItem
            // 
            this.iTEMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.iTEMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.iTEMToolStripMenuItem.Name = "iTEMToolStripMenuItem";
            this.iTEMToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.iTEMToolStripMenuItem.Text = "NAME";
            this.iTEMToolStripMenuItem.Click += new System.EventHandler(this.iTEMToolStripMenuItem_Click);
            // 
            // dATEToolStripMenuItem
            // 
            this.dATEToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.dATEToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dATEToolStripMenuItem.Name = "dATEToolStripMenuItem";
            this.dATEToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.dATEToolStripMenuItem.Text = "ITEM\'S";
            this.dATEToolStripMenuItem.Click += new System.EventHandler(this.dATEToolStripMenuItem_Click);
            // 
            // cREDITORSToolStripMenuItem
            // 
            this.cREDITORSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cREDITORSFORMToolStripMenuItem,
            this.sEARCHToolStripMenuItem3});
            this.cREDITORSToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.cREDITORSToolStripMenuItem.Image = global::stocktaking2.Properties.Resources._9;
            this.cREDITORSToolStripMenuItem.Name = "cREDITORSToolStripMenuItem";
            this.cREDITORSToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.cREDITORSToolStripMenuItem.Text = "CREDITOR\'S";
            // 
            // cREDITORSFORMToolStripMenuItem
            // 
            this.cREDITORSFORMToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.cREDITORSFORMToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.cREDITORSFORMToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cREDITORSFORMToolStripMenuItem.Image")));
            this.cREDITORSFORMToolStripMenuItem.Name = "cREDITORSFORMToolStripMenuItem";
            this.cREDITORSFORMToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.cREDITORSFORMToolStripMenuItem.Text = "CREDITOR\'S FORM";
            this.cREDITORSFORMToolStripMenuItem.Click += new System.EventHandler(this.cREDITORSFORMToolStripMenuItem_Click);
            // 
            // sEARCHToolStripMenuItem3
            // 
            this.sEARCHToolStripMenuItem3.BackColor = System.Drawing.Color.Lime;
            this.sEARCHToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nAMEToolStripMenuItem,
            this.iTEMSToolStripMenuItem});
            this.sEARCHToolStripMenuItem3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sEARCHToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("sEARCHToolStripMenuItem3.Image")));
            this.sEARCHToolStripMenuItem3.Name = "sEARCHToolStripMenuItem3";
            this.sEARCHToolStripMenuItem3.Size = new System.Drawing.Size(220, 26);
            this.sEARCHToolStripMenuItem3.Text = "SEARCH";
            // 
            // nAMEToolStripMenuItem
            // 
            this.nAMEToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.nAMEToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.nAMEToolStripMenuItem.Name = "nAMEToolStripMenuItem";
            this.nAMEToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.nAMEToolStripMenuItem.Text = "NAME";
            this.nAMEToolStripMenuItem.Click += new System.EventHandler(this.nAMEToolStripMenuItem_Click);
            // 
            // iTEMSToolStripMenuItem
            // 
            this.iTEMSToolStripMenuItem.BackColor = System.Drawing.Color.Lime;
            this.iTEMSToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.iTEMSToolStripMenuItem.Name = "iTEMSToolStripMenuItem";
            this.iTEMSToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.iTEMSToolStripMenuItem.Text = "ITEM\'S";
            this.iTEMSToolStripMenuItem.Click += new System.EventHandler(this.iTEMSToolStripMenuItem_Click);
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(959, 437);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Main Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sTOCKINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOCKINFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHITEMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOCKOUTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOCKOUTFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHITEMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pLREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dEBTORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dEBTORFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dEBTORREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cREDITORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cREDITORFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cREDITORSREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHDEBTORBYITEMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchByDateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHBYITEMToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sTOCKINToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sTOCKINFORMToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sEARCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHBYITEMToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sEARCHBYDATEToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sTOCKOUTToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bYITEMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bYDATEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROFITANDLOSSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTATEMENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dEBTORSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dEBTORSFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem iTEMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dATEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cREDITORSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cREDITORSFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem nAMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iTEMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pLREPORTBYACCOUNTPERIODToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHACCOUNTINGPERIODToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHBYACCOUNTPERIODToolStripMenuItem;
    }
}

